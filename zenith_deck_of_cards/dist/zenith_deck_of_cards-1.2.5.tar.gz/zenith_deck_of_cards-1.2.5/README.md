Import like this:  
```py
import zenith_deck  
```  
Source Code:  
https://github.com/Zenith4/Zenith-Deck-of-Cards  
Documentation:  
Nonexistent (As of now)           
        
